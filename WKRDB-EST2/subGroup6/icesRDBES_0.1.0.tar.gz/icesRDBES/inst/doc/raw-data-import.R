## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(icesRDBES)

## -----------------------------------------------------------------------------
#directory holding the files
ddir <- "./tests/testthat/h1_v_1_19/"

#the files to import
zipFiles <- c("H1_2021_000_example.zip",
             "HSL_2021_002_example.zip",
             "HVD_2021_001_example.zip",
             "VesselSelection.csv")

#adding full path
zipFiles <- paste0(ddir, zipFiles)

## -----------------------------------------------------------------------------
importedTables <- importRDBESDownloadData(zipFiles[2])
#print the not NULL table names
names(importedTables[!unlist(lapply(importedTables, is.null))])

## -----------------------------------------------------------------------------
importedTables <- importRDBESDownloadData(zipFiles[4])
#print the not NULL table names
names(importedTables[!unlist(lapply(importedTables, is.null))])

## -----------------------------------------------------------------------------
importedTables <- importRDBESDownloadData(zipFiles[3:4])
#print the not NULL table names
names(importedTables[!unlist(lapply(importedTables, is.null))])

## -----------------------------------------------------------------------------
importedTables <- importRDBESDownloadData(zipFiles)
#print the not NULL table names
names(importedTables[!unlist(lapply(importedTables, is.null))])

## -----------------------------------------------------------------------------
#END

