#' setRDBESRawObjectDataTypes For a given rdbesRawObject convert the required
#' columns to the correct data types.  (This function can cause an error if we
#' have data in the columns that can't be cast to the desired data type.)
#'
#' @param rdbesRawObject
#'
#' @return
#'
#' @examples
#' @import data.table
setRDBESRawObjectDataTypes <- function(rdbesRawObjectToConvert){

  # For testing - to be removed!
  #rdbesExtractPath <- "H:\\git\\WK_RDBES\\WKRDB-EST2\\subGroup6\\icesRDBES\\tests\\testthat\\h1_v_1_19"
  #load("H:\\git\\WK_RDBES\\WKRDB-EST2\\subGroup6\\icesRDBES\\data\\mapColNamesFieldR.RData")
  #rdbesRawObject <- createRDBESRawObject(rdbesExtractPath = rdbesExtractPath, castColsToCorrectDataTypes = FALSE)
  #require(data.table)

  # https://stackoverflow.com/questions/47142266/how-to-importfrom-data-table-within-r-package-function/47146007#47146007
  .SD = .N = .I = .GRP = .BY = .EACHI = NULL


  #rdbesRawObject <- myRDBESRawObject
  # For each entry in our list convert the columns to the correct format
  # This could cause an error if we have data in the columns that can't be
  # cast to the desired data type
  objectToReturn <- lapply(rdbesRawObjectToConvert,function(x){
      print(class(x))
      # Only process the non-null entries
      if (!is.null(x)){
        # Assume the first field name accurately gives us the table name
        tableName <- substring(names(x)[1], 1, 2)
        # Find information for the relevent columns
        requiredColumns <-
          mapColNamesFieldR[mapColNamesFieldR$Table.Prefix == tableName, ]
        # Change to numeric
        myCols <-
          requiredColumns[requiredColumns$RDataType == "numeric","R.Name"]
        #colsToChange <- names(x)[names(x) %in% myCols]
        colsToChange <- which(names(x) %in% myCols)
        #print(colsToChange)
        if (length(colsToChange)>0){

          #fkt_idx = which(sapply(Teams, is.factor))
          x[ , (colsToChange) := lapply(.SD, as.numeric), .SDcols = colsToChange]

          #x[, colsToChange] <-
          #  x[, lapply(.SD, as.numeric), .SDcols = colsToChange]
        }
        # # Change to integer
        # myCols <-
        #   requiredColumns[requiredColumns$RDataType == "integer","R.Name"]
        # colsToChange <- names(x)[names(x) %in% myCols]
        # #print(colsToChange)
        # if (length(colsToChange)>0){
        #   x[, colsToChange] <-
        #     x[, lapply(.SD, as.integer), .SDcols = colsToChange]
        # }
        # # Change to character
        # myCols <-
        #   requiredColumns[requiredColumns$RDataType == "character","R.Name"]
        # colsToChange <- names(x)[names(x) %in% myCols]
        # #print(colsToChange)
        # if (length(colsToChange)>0){
        #   x[, colsToChange] <-
        #     x[, lapply(.SD, as.character), .SDcols = colsToChange]
        # }
      }
      x
    }
  )

  objectToReturn

}
