test_that("createRDBESRawObject can create an empty object without errors
          or warnings",  {

  expect_warning(createRDBESRawObject(),NA)
  expect_error(createRDBESRawObject(),NA)
})
test_that("createRDBESRawObject can create an object from an H1 data extract
          without errors or warnings",  {

  myPath <- ".\\h1_v_1_19"
  myPath <- "H:\\git\\WK_RDBES\\WKRDB-EST2\\subGroup6\\icesRDBES\\tests\\testthat\\h1_v_1_19"

  expect_warning(createRDBESRawObject(rdbesExtractPath = myPath),NA)
  expect_error(createRDBESRawObject(rdbesExtractPath = myPath),NA)
})
test_that("createRDBESRawObject can create an object from an H5 data extract
          without errors or warnings",  {

  myPath <- ".\\h5_v_1_19"

  expect_warning(createRDBESRawObject(rdbesExtractPath = myPath),NA)
  expect_error(createRDBESRawObject(rdbesExtractPath = myPath),NA)
})
test_that("createRDBESRawObject can create an object from an H1 data extract by specifying file names without errors or warnings",  {

  myPath <- ".\\h1_v_1_19"
  myFileNames <- list("DE"="DE.csv","SD"="SD.csv")

  expect_warning(createRDBESRawObject(rdbesExtractPath = myPath, listOfFileNames = myFileNames),NA)
  expect_error(createRDBESRawObject(rdbesExtractPath = myPath, listOfFileNames = myFileNames),NA)
})
test_that("createRDBESRawObject will give a warning if given a dir with no relevent files in it",  {

  myPath <- "."
  expect_warning(createRDBESRawObject(rdbesExtractPath = myPath),"No relevent files found in given directory - an empty object will be created")
})
