library(testthat)
library(icesRDBES)

test_check("icesRDBES")
